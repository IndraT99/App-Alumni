package com.example.app_alumni

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
